import React from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

function App() {
  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">◐</span><span>ECLIPSE NOTES</span></div>
        <button className="new-note">＋ New note</button>
        <nav>
          <a className="active">⌂　All notes</a>
          <a>☆　Favorites</a>
          <a>▤　Templates</a>
          <a>▱　Archive</a>
        </nav>
        <div className="section-label">WORKSPACE</div>
        <a>▸　Projects</a>
        <div className="sidebar-footer">Local workspace · Offline ready</div>
      </aside>
      <section className="content">
        <header><div><p className="eyebrow">YOUR WORKSPACE</p><h1>All notes</h1></div><button className="icon-button" aria-label="Search">⌕</button></header>
        <div className="empty-state">
          <div className="empty-icon">✧</div>
          <h2>Your space, your thoughts.</h2>
          <p>Your notes will live here. Create your first note to get started.</p>
          <button className="primary">＋ Create your first note</button>
        </div>
      </section>
    </main>
  );
}

createRoot(document.getElementById("root")!).render(<React.StrictMode><App /></React.StrictMode>);
