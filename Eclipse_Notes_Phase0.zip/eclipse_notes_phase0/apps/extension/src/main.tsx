import React from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

function App() {
  return <main><header><span className="mark">◐</span><strong>ECLIPSE NOTES</strong></header><button>＋ New note</button><section><h1>Quick capture</h1><p>Capture an idea now. Organize it into a project later.</p><div className="placeholder">Your notes will appear here.</div></section><footer>Stored locally · No account required</footer></main>;
}
createRoot(document.getElementById("root")!).render(<React.StrictMode><App /></React.StrictMode>);
