chrome.runtime.onInstalled.addListener(() => {
  // Phase 0: extension lifecycle hook only. Persistence is implemented in Phase 1.
});
