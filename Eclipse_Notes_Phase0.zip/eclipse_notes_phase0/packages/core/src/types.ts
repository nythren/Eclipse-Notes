export type EntityId = string;

export interface Note {
  id: EntityId;
  projectId: EntityId | null;
  folderId: EntityId | null;
  title: string;
  /** Versioned TipTap/ProseMirror JSON document. */
  content: Record<string, unknown>;
  plainText: string;
  color: string | null;
  isPinned: boolean;
  isArchived: boolean;
  isDeleted: boolean;
  createdAt: number;
  updatedAt: number;
  sourceUrl?: string;
  sourceTitle?: string;
}

export interface Project {
  id: EntityId;
  name: string;
  description: string;
  color: string | null;
  createdAt: number;
  updatedAt: number;
}

export interface Folder {
  id: EntityId;
  projectId: EntityId;
  parentId: EntityId | null;
  name: string;
  createdAt: number;
  updatedAt: number;
}

export interface Tag {
  id: EntityId;
  name: string;
}

export interface NoteTag {
  noteId: EntityId;
  tagId: EntityId;
}

export interface NoteTemplate {
  id: EntityId;
  name: string;
  description: string;
  category: string;
  content: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
  isBuiltIn: boolean;
}

export interface ExportEnvelope {
  format: "eclipse-notes-export";
  schemaVersion: 1;
  exportedAt: string;
  data: {
    notes: Note[];
    projects: Project[];
    folders: Folder[];
    tags: Tag[];
    noteTags: NoteTag[];
    templates: NoteTemplate[];
  };
}
