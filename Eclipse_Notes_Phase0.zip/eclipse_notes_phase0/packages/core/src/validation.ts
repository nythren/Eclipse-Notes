import type { ExportEnvelope, Folder } from "./types";

export function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

export function validateFolderParent(folder: Folder, folders: Folder[]): boolean {
  if (!folder.parentId) return true;
  if (folder.parentId === folder.id) return false;

  const byId = new Map(folders.map((item) => [item.id, item]));
  const seen = new Set<string>([folder.id]);
  let current: Folder | undefined = byId.get(folder.parentId);

  while (current) {
    if (seen.has(current.id)) return false;
    if (current.projectId !== folder.projectId) return false;
    seen.add(current.id);
    current = current.parentId ? byId.get(current.parentId) : undefined;
  }
  return true;
}

export function isExportEnvelope(value: unknown): value is ExportEnvelope {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<ExportEnvelope>;
  return candidate.format === "eclipse-notes-export"
    && candidate.schemaVersion === 1
    && typeof candidate.exportedAt === "string"
    && !!candidate.data
    && Array.isArray(candidate.data.notes)
    && Array.isArray(candidate.data.projects)
    && Array.isArray(candidate.data.folders)
    && Array.isArray(candidate.data.tags)
    && Array.isArray(candidate.data.noteTags)
    && Array.isArray(candidate.data.templates);
}
