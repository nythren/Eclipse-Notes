# Architecture Decision Records

## ADR-001: Tauri 2 for Desktop
**Status:** Accepted  
**Decision:** Use Tauri 2 with React and TypeScript.  
**Reason:** Lightweight native shell and a clear boundary between UI and local platform capabilities.  
**Trade-off:** Requires Rust toolchain and OS-specific testing.

## ADR-002: Dark-only v1
**Status:** Accepted  
**Decision:** Ship a dark theme only in the first version.  
**Reason:** Keep the initial design system focused and consistent.  
**Future:** Add light theme only after v1 usability is validated.

## ADR-003: Separate local databases
**Status:** Accepted  
**Decision:** SQLite for Desktop and IndexedDB for Chrome.  
**Reason:** Each platform gets a storage mechanism suited to its runtime.  
**Trade-off:** No automatic cross-platform sync in v1.

## ADR-004: Defer Local Bridge
**Status:** Accepted  
**Decision:** Use explicit versioned import/export before implementing a local bridge.  
**Reason:** Reduce attack surface and avoid early complexity.

## ADR-005: Optional AI
**Status:** Accepted  
**Decision:** AI is disabled by default and must not be required for core workflows.  
**Reason:** Preserve privacy, offline utility, and user control.
