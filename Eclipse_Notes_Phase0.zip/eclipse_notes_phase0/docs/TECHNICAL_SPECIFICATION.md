# Eclipse Notes — Technical Specification v1.0

## 1. Approved decisions
| Area | Decision |
|---|---|
| Desktop | Tauri 2 + React + TypeScript |
| Browser | Chrome Extension Manifest V3 + React + TypeScript |
| Appearance | Dark theme only in v1 |
| Desktop storage | SQLite |
| Extension storage | IndexedDB |
| Shared logic | TypeScript package `@eclipse/core` |
| Bridge | Deferred; JSON export/import first |
| AI | Optional, disabled by default; local inference preferred |
| Cloud | No cloud dependency in v1 |

## 2. System architecture
The apps share domain types, validation, normalization, and pure business rules from `packages/core`. They do not share a database. Each platform has its own persistence adapter.

Desktop:
`React UI → shared core → Tauri command boundary → SQLite`

Chrome:
`React UI → shared core → extension persistence adapter → IndexedDB`

The Tauri command boundary must expose narrowly scoped operations. Do not expose arbitrary SQL execution to the frontend.

## 3. Domain model
### Note
- `id`: stable UUID
- `projectId`: nullable project reference
- `folderId`: nullable folder reference
- `title`: plain text
- `content`: versioned TipTap/ProseMirror JSON document
- `plainText`: derived searchable text
- `color`: optional semantic note color
- `isPinned`, `isArchived`, `isDeleted`: booleans
- `createdAt`, `updatedAt`: Unix milliseconds
- `sourceUrl`, `sourceTitle`: optional browser context, only when explicitly attached by user

### Project
- `id`, `name`, `description`, `color`, `createdAt`, `updatedAt`

### Folder
- `id`, `projectId`, `parentId`, `name`, `createdAt`, `updatedAt`
- Nested folders must prevent cycles and cross-project parent references.

### Tag
- `id`, `name`
- Join table `note_tags` for many-to-many relationships.

### Template
- `id`, `name`, `description`, `category`, `content`, `createdAt`, `updatedAt`, `isBuiltIn`

## 4. Persistence
### Desktop
SQLite with migrations. Use transactions for note updates and imports. Enable foreign keys. Use parameterized queries. Keep DB backups before schema migrations.

### Chrome
IndexedDB with versioned schema upgrades. Use transactions for multi-record updates. Avoid relying on `chrome.storage.local` for the main rich-note database.

### Import/export
Versioned JSON envelope:
- `format`: `eclipse-notes-export`
- `schemaVersion`: integer
- `exportedAt`: ISO timestamp
- `data`: projects, folders, notes, tags, templates

Validate the full payload and report conflicts before writing. Never silently overwrite existing notes.

## 5. Editor
TipTap with a controlled extension set:
- StarterKit (headings, paragraphs, lists, blockquotes, code blocks)
- Link
- TaskList / TaskItem
- Image (local attachments only in v1)
- Table (optional after core editor stability)

Persist JSON document, derive plain text for search. Sanitize imported HTML if HTML import is ever added. Do not treat arbitrary HTML as trusted.

## 6. Search
v1: local indexed search across title, plainText, project, folder, and tags. Debounce UI input; rank title matches above body matches. Search must never require network access.

## 7. Desktop windows
- Main workspace window.
- Floating note windows opened from a note.
- Always-on-top toggle controlled by user.
- Window geometry stored locally.
- Window close must not discard unsaved editor state.
- OS-specific behavior and permissions require manual QA.

## 8. Chrome extension
- Manifest V3 service worker.
- Popup for quick capture.
- Side panel for full note browsing/editing.
- Content scripts are not required for basic v1.
- If page context is added, request only the minimum permissions and capture URL/title only on explicit user action.
- Extension UI cannot guarantee a system-wide floating overlay.

## 9. AI boundary
AI is optional and disabled by default. The core app must remain fully useful without AI.
- AI requests are initiated by explicit user action.
- Local inference adapter is the default integration direction.
- No note content is sent to a remote endpoint unless a future setting clearly explains the provider, data sent, and user consent.
- AI output is a suggestion; it must not overwrite note content without confirmation.

## 10. Security and privacy
- No analytics or telemetry by default.
- No account or identity permission in the extension v1 manifest.
- Validate all imported data and URLs.
- Treat note content and imported files as untrusted input.
- Keep secrets out of the repository.
- Apply a restrictive Content Security Policy to the extension.
- Use least-privilege Tauri capabilities and commands.

## 11. Testing
- Unit tests for core validation, folder tree rules, export/import, and search normalization.
- Persistence integration tests for each adapter.
- UI tests for create/edit/autosave/search.
- Recovery tests for malformed import and interrupted writes.
- Manual cross-platform QA for floating windows and always-on-top.
