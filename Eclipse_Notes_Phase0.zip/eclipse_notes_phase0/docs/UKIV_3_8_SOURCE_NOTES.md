# Reference audit: Ukiv Sticky Notes 3.8 archive

This note records only directly inspected facts from the supplied ZIP.

- The archive contains 180 entries.
- `manifest.json` identifies the extension as “Sticky Notes 3.8 - Super Quick & Personal”, version `3.8`, Manifest V3.
- The manifest declares `offline_enabled: true`.
- Declared permissions are `storage`, `identity`, and `system.display`.
- The action popup is `index.html`.
- The background service worker is `service_worker.js` and is declared as a module.
- The manifest includes an OAuth client ID and userinfo email/profile scopes.
- `service_worker.js` imports Sentry and Amplitude modules, initializes Sentry and Amplitude, initializes a message helper, and calls extension install/update initialization.
- `background/backgroundHelpers/localstorageHelper.js` reads and writes through `chrome.storage.local`.
- That helper contains a `migrateFromIndexdb` method which attempts to obtain IndexedDB data through `MigrationHelper`, then writes the resulting map into Chrome local storage.
- `background/backgroundHelpers/indexdbHelper.js` is commented out in the inspected archive. It contains legacy IndexedDB creation and migration logic, so it should not be described as the active primary persistence implementation without further runtime tracing.
- The archive includes Firebase 9.9.3 library files and Quill 1.3.6 library files. Their presence alone does not prove which exact user data is transmitted or when.

## Implication for Eclipse Notes
The new product intentionally does not reproduce the original service integrations. It uses local-first storage, no account permission in the initial extension manifest, no telemetry by default, and explicit export/import before any cross-platform bridge.
