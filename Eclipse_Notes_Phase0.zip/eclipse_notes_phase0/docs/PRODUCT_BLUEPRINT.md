# Eclipse Notes — Product Blueprint v1.0

## Product vision
Eclipse Notes is a work-focused, local-first workspace for capturing, organizing, editing, and retrieving project knowledge. It combines quick sticky-note capture with structured project organization and a rich editor.

**Product promise:** Capture anything. Organize everything. Find it instantly.

## Target experience
- Fast capture through a desktop floating note and a Chrome popup/side panel.
- Notes organized by projects, folders, favorites, archive, and tags.
- Rich content editing with predictable local persistence.
- Templates for repeatable work.
- Optional AI assistance, with explicit user control and no automatic cloud upload.

## Platforms
### Desktop
- Tauri 2 shell with React + TypeScript UI.
- Independent note windows and always-on-top behavior are planned.
- SQLite is the intended local persistence layer.
- OS-specific window behavior must be tested per target platform.

### Chrome
- Manifest V3 extension with popup and side panel.
- IndexedDB is the intended local persistence layer.
- The extension cannot create OS-level always-on-top windows; that capability belongs to Desktop.
- Page-associated notes may store the page URL/title only when the user creates or links such a note.

## v1 feature scope
### P0
- Create, edit, delete, pin, archive, and search notes.
- Projects and nested folders.
- Rich text editor.
- Autosave with visible save status.
- Dark theme only.
- Local persistence on each platform.
- JSON export/import and recovery validation.
- Desktop shell and Chrome popup/side panel.

### P1
- Templates and user-created templates.
- Tags and advanced filters.
- Keyboard shortcuts and productivity refinements.

### P2
- Optional AI tools: summarize, suggest title, extract tasks, and search note knowledge.
- AI disabled by default. Local inference is preferred. Any remote provider would require a separate explicit opt-in and clear disclosure.

## Explicit non-goals for v1
- Accounts, mandatory sign-in, cloud sync, analytics, advertising, or telemetry.
- Automatic Desktop–Chrome synchronization.
- Collaboration and shared workspaces.
- AI processing without a user action.

## Product quality requirements
- No note content is transmitted by default.
- Autosave must be resilient to app closure and interrupted writes.
- Export format must be versioned and import must validate before modifying user data.
- Search must index titles and plain-text representations of editor content.
- Accessibility: keyboard navigation, visible focus, semantic controls, and readable contrast.
