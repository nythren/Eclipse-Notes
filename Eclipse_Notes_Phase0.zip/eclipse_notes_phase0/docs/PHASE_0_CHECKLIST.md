# Phase 0 — Foundation checklist

- [x] Confirm product decisions.
- [x] Write product blueprint and technical specification.
- [x] Record architecture decisions.
- [x] Create monorepo workspace layout.
- [x] Define shared domain types and initial validation helpers.
- [x] Add dark-only desktop and extension UI shells.
- [x] Add minimal Manifest V3 extension manifest.
- [ ] Install dependencies and run typecheck/build in a Node + Rust environment.
- [ ] Generate Tauri 2 Rust host and least-privilege capabilities.
- [ ] Add automated test runner and CI.
- [ ] Verify Chrome popup and side panel behavior in a real browser.

Phase 0 is scaffolded; it is not yet build-verified or release-ready.
